# Smart Embedded Alarm System

## Build Instructions

1. Open terminal
2. Run: make
3. Execute: sudo ./alarm_app

## GitHub Link
[PLACEHOLDER: Insert GitHub Link]

## Screencast Link
[PLACEHOLDER: Insert Video Link]
