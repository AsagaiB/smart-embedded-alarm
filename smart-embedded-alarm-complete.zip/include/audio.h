#ifndef AUDIO_H
#define AUDIO_H

void audio_init();
void audio_generate_alarm_tone();

#endif
